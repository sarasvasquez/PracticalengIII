import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.io.IOException;
import java.util.regex.Pattern;
import java.util.stream.*;


                          class Main {




                              static List<Estudiante> estudiantes;


                              public static void main(String[] args) throws IOException {
                                  cargarArchivo();//cargo el archivo
                                  mostrarEstudiantePorCarr();
                                  cantEstudiantePorCarr();
                                  cantEstudiantePorGen();
                                  imprimirCantidadMujeresHombresPorCarrera();
                                  EstudianteGanaMasPorCarr();
EstudianteMayPun();
promPunCarr();
                                  
                              }


                              static void cargarArchivo() throws IOException {
                                  Pattern pattern = Pattern.compile(",");
                                  String filename = "student-scores.csv";

                                  try (Stream<String> lines = Files.lines(Path.of(filename))) {
                                      estudiantes = lines.skip(1).map(line -> { 
                                          String[] arr = pattern.split(line);
                                          return new Estudiante(arr[0], arr[1], arr[2], arr[4], Double.parseDouble(arr[10]), arr[9]);
                                      }).collect(Collectors.toList()); 
                                      estudiantes.forEach(System.out::println);
                                  }
                              }

                              static void mostrarEstudiantePorCarr() {
                                  System.out.printf("%nEmpleados por Carrera:%n");
                                  Map<String, List<Estudiante>> agrupadoPorCarrera =
                                          estudiantes.stream()
                                                  .collect(Collectors.groupingBy(Estudiante::getCarrera));
                          
                                  agrupadoPorCarrera.forEach(
                                          

                                          (carrera, estudiantesEnCarrera) ->
                                                  
                                          {

                                              System.out.println(carrera);
                                              estudiantesEnCarrera.forEach(
                                                     

                                                      estudiante -> System.out.printf(" %s%n", estudiante));

                                          }
                                  );
                              }

                              static void cantEstudiantePorGen() {
  
                                  System.out.printf("%nConteo de estudiantes por genero:%n");
                                  Map<String, Long> conteoEmpleadosPorGenero =
                                          estudiantes.stream()
                                                  .collect(Collectors.groupingBy(Estudiante::getGenero,
                                                          TreeMap::new, Collectors.counting()));


                                  conteoEmpleadosPorGenero.forEach(
                                          (Genero, conteo) -> System.out.printf(
                                                  "%s tiene %d estudiante(s)%n", Genero, conteo));
                              }

                              static Map<String, Map<String, Long>> obtenerCantidadMujeresHombresPorCarrera() {
 
                                  Map<String, Map<String, Long>> cantidadMujeresHombresPorCarrera = new TreeMap<>();

 
                                  Map<String, List<Estudiante>> agrupadoPorCarrera = estudiantes.stream()
                                          .collect(Collectors.groupingBy(Estudiante::getCarrera, TreeMap::new, Collectors.toList()));

                    agrupadoPorCarrera.forEach((carrera, estudiantesEnCarrera) -> {
                                      Map<String, Long> cantidadMujeresHombres = estudiantesEnCarrera.stream()
                                              .collect(Collectors.groupingBy(
                                                      Estudiante::getGenero,
                                                      TreeMap::new, Collectors.counting()
                                              ));
                                      cantidadMujeresHombresPorCarrera.put(carrera, cantidadMujeresHombres);
                                  });

                                  return cantidadMujeresHombresPorCarrera;
                              }

                              static void imprimirCantidadMujeresHombresPorCarrera() {
                                  Map<String, Map<String, Long>> cantidadMujeresHombresPorCarrera = obtenerCantidadMujeresHombresPorCarrera();

                                  cantidadMujeresHombresPorCarrera.forEach((carrera, cantidadMujeresHombres) -> {
                                      System.out.println("Carrera: " + carrera+ "\n");
                                      System.out.println("Mujeres: " + cantidadMujeresHombres.get("female"));
                                      System.out.println("Hombres: " + cantidadMujeresHombres.get("male")+"\n");
                                  });
                              }

                              static void cantEstudiantePorCarr() {

                                  System.out.printf("%nConteo de estudiantes por carrera:%n");
                                  Map<String, Long> conteoEstudiantePorCarrera =
                                          estudiantes.stream()
                                                  .collect(Collectors.groupingBy(Estudiante::getCarrera,
                                                          TreeMap::new, Collectors.counting()));
                                  

                                  conteoEstudiantePorCarrera.forEach(
                                          (Carrera, conteo) -> System.out.printf(
                                                  "%s tiene %d estudiante(s)%n", Carrera, conteo));
                              }

                              static void EstudianteGanaMasPorCarr() {
                              Function<Estudiante, Double> porPuntaje = Estudiante::getPuntaje;
                              Comparator<Estudiante> PuntajeDescendete = Comparator.comparing(porPuntaje);
                              System.out.printf("%nEstudiantes con el puntaje más alto por Carrera: %n");
                              Map<String, List<Estudiante>> agrupadoPorCarrera =
                                      estudiantes.stream().collect(Collectors.groupingBy(Estudiante::getCarrera));

                              agrupadoPorCarrera.forEach(
                                  (Carrera, estudiantesEnCarrera) -> {
                                      System.out.println(Carrera + ":");
                                      Double maxPuntaje = estudiantesEnCarrera.stream().mapToDouble(Estudiante::getPuntaje).max().orElse(0.0);

                                      estudiantesEnCarrera.stream()
                                          .filter(estudiante -> estudiante.getPuntaje() == maxPuntaje)
                                          .forEach(estudiante -> {
                                              System.out.println(estudiante.getPrimerNombre() + " " + estudiante.getApellidoPaterno() +
                                                      " ///Cuanto puntaje ==> puntaje: " + estudiante.getPuntaje());
                                          });
                                  }
                              );
                          }


                              static void EstudianteMayPun() {
                                  Function<Estudiante, Double> porPuntaje = Estudiante::getPuntaje;
                                  Comparator<Estudiante> PuntajeCarrera = Comparator.comparing(porPuntaje);
                                  Double maxPuntaje = estudiantes.stream().mapToDouble(Estudiante::getPuntaje).max().orElse(0.0);

                                  System.out.printf("%nEstudiantes con el puntaje más alto (Puntaje máximo: %.2f)%n", maxPuntaje);

                                  estudiantes.stream()
                                          .filter(estudiante -> estudiante.getPuntaje() == maxPuntaje)
                                          .forEach(estudiante -> {
                                              System.out.println(estudiante.getPrimerNombre() + " " + estudiante.getApellidoPaterno());
                                          });
                              }

                              static void promPunCarr(){
                                  Map<String, List<Estudiante>> agrupadoPorCarrera =
                                          estudiantes.stream()
                                                  .collect(Collectors.groupingBy(Estudiante::getCarrera));
                                  System.out.println("\nPromedio de puntaje de los estudiantes por Carrera:");
                                  agrupadoPorCarrera.forEach((carrera, estudiantesporCarr)-> {
                                      System.out.print(carrera+": ");
                                      System.out.println(estudiantesporCarr
                                              .stream()
                                              .mapToDouble(Estudiante::getPuntaje)
                                              .average()
                                              .getAsDouble());
                                  });


                              }

                          }
          
          
        
 

          
